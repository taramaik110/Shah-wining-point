
document.getElementById("loginForm").addEventListener("submit", async function(e) {
  e.preventDefault();
  const phone = document.getElementById("phone").value;
  const password = document.getElementById("password").value;

  const res = await fetch("https://shah-wining-backend.vercel.app/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ phone, password })
  });
  const data = await res.json();
  if (data.success) {
    localStorage.setItem("userToken", data.token);
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("game").style.display = "block";
    renderBoxes();
  } else {
    alert(data.message);
  }
});

function renderBoxes() {
  const container = document.getElementById("boxContainer");
  for (let i = 1; i <= 100; i++) {
    const div = document.createElement("div");
    div.className = "box";
    div.innerText = i;
    div.dataset.number = i;
    div.onclick = selectBox;
    container.appendChild(div);
  }
}

async function selectBox() {
  const token = localStorage.getItem("userToken");
  const res = await fetch("https://shah-wining-backend.vercel.app/api/select-box", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify({ boxNumber: this.dataset.number })
  });
  const data = await res.json();
  document.getElementById("status").innerText = data.message;
}

fetch("https://shah-wining-backend.vercel.app/api/winner")
  .then(res => res.json())
  .then(data => {
    document.getElementById("winnerBox").innerText = "Winner Box: " + data.winner;
  });
